﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using retrive2.Data;
using System.Reflection.Metadata.Ecma335;

namespace retrive2.Controllers
{
    [Microsoft.AspNetCore.Components.Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UserController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("inactive")]
        public async Task<IActionResult> GetInactiveUsers()
        {
            var threshold = DateTime.UtcNow.AddDays(-30);

            var result = await _context.Users.Include(u => u.UsersDetails)
                .Where(u => u.UsersDetails != null && u.UsersDetails.RecentLoginDate8 < threshold)
                .Select(u => new
                {
                    u.Id,
                    u.Name,
                    u.CreateDate,
                    UsersDetails = new
                    {
                        u.UsersDetails.Id,
                        u.UsersDetails.Email,
                        u.UsersDetails.RecentLoginDate8
                    }
                }).ToListAsync();

            return Ok(result);
        }
    }
}
